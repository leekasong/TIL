
// stdafx.cpp : source file that includes just the standard includes
// ExamCOPY_DATA1.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"


//wchar_t * -> char *
BOOL KS_WideToMulti(PCHAR pMultiStr, PWCHAR pWideStr) {

	if (pMultiStr == NULL || pWideStr == NULL) {
		return FALSE;
	}
	int len = ::WideCharToMultiByte(CP_ACP, 0, pWideStr, -1, NULL, 0, NULL, NULL);
	::WideCharToMultiByte(CP_ACP, 0, pWideStr, -1, pMultiStr, len, NULL, NULL);
	return TRUE;
}

//char * -> wchar_t *
BOOL KS_MultiToWide(PWCHAR pWideStr, PCHAR pMultiStr) {
	if (pMultiStr == NULL || pWideStr == NULL) {
		return FALSE;
	}
	int len = ::MultiByteToWideChar(CP_ACP, 0, pMultiStr, -1, NULL, 0);
	::MultiByteToWideChar(CP_ACP, 0, pMultiStr, -1, pWideStr, len);
	return TRUE;
}