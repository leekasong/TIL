
// ExamCOPY_DATA1Dlg.h : header file
//

#pragma once


// CExamCOPY_DATA1Dlg dialog
class CExamCOPY_DATA1Dlg : public CDialogEx
{
private:
	HWND m_hTarget;
	HANDLE m_hRcvEve;
// Construction
public:
	CExamCOPY_DATA1Dlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_EXAMCOPY_DATA1_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CString m_edit_string;
	CString m_edit_file;
	afx_msg void OnBnClickedButtonSendString();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnDestroy();
};
