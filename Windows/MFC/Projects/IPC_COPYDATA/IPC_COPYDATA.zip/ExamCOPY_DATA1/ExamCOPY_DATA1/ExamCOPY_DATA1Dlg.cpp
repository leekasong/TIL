
// ExamCOPY_DATA1Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "ExamCOPY_DATA1.h"
#include "ExamCOPY_DATA1Dlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CExamCOPY_DATA1Dlg dialog



CExamCOPY_DATA1Dlg::CExamCOPY_DATA1Dlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_EXAMCOPY_DATA1_DIALOG, pParent)
	, m_edit_string(_T(""))
	, m_edit_file(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CExamCOPY_DATA1Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_STRING, m_edit_string);
	DDX_Text(pDX, IDC_EDIT_FILE, m_edit_file);
}

BEGIN_MESSAGE_MAP(CExamCOPY_DATA1Dlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_SEND_STRING, &CExamCOPY_DATA1Dlg::OnBnClickedButtonSendString)
	ON_BN_CLICKED(IDC_BUTTON2, &CExamCOPY_DATA1Dlg::OnBnClickedButton2)
	ON_WM_DESTROY()
END_MESSAGE_MAP()


// CExamCOPY_DATA1Dlg message handlers

BOOL CExamCOPY_DATA1Dlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_hTarget = ::FindWindow(NULL, _T("ExamCOPY_DATA2"));
	m_hRcvEve = CreateEvent(NULL, FALSE, FALSE, _T("RECEIVE_NOTI_EVENT"));

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CExamCOPY_DATA1Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CExamCOPY_DATA1Dlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CExamCOPY_DATA1Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CExamCOPY_DATA1Dlg::OnBnClickedButtonSendString()
{
	UpdateData();
	COPYDATASTRUCT cds;
	cds.dwData = 1;
	//cds.cbData = 255 * 2;//m_edit_string.GetLength();
	char buf[255*2] = { 0 };
	KS_WideToMulti(buf, m_edit_string.GetBuffer());
	cds.lpData = buf;
	cds.cbData = strlen(buf);

	::SendMessage(m_hTarget, WM_COPYDATA, (WPARAM)m_hTarget, (LPARAM)&cds);
	
}


void CExamCOPY_DATA1Dlg::OnBnClickedButton2()
{

	CFileDialog dlg(TRUE, _T("All"), NULL, OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST, _T("All files(*.*)|*.*||"), this);
	if (dlg.DoModal() == IDOK) {
		CString str = dlg.GetPathName();
		m_edit_file = str;
		UpdateData(FALSE);
		char file_path[MAX_PATH + _MAX_FNAME] = { 0 };
		KS_WideToMulti(file_path, str.GetBuffer());
		FILE *fp = fopen(file_path, "rb");
		fseek(fp, 0, SEEK_END);
		int file_size = ftell(fp);
		fseek(fp, 0, SEEK_SET);
		char *pBuf = new char[file_size]{0};
		
		int nRead = 0;
		while (!feof(fp)) {
			int tmp = fread(pBuf + nRead, sizeof(char), file_size, fp);
			nRead += tmp;
		}
		fread(pBuf + file_size - nRead, sizeof(char), file_size - nRead, fp);
		COPYDATASTRUCT cds;
		cds.dwData = 2;
		cds.cbData = file_size;
		cds.lpData = pBuf;
		::SendMessage(m_hTarget, WM_COPYDATA, (WPARAM)m_hTarget, (LPARAM)&cds);
		WaitForSingleObject(m_hRcvEve, INFINITE);
		fclose(fp);
		delete[] pBuf;
	}

}


void CExamCOPY_DATA1Dlg::OnDestroy()
{
	CDialogEx::OnDestroy();

	CloseHandle(m_hRcvEve);
}
