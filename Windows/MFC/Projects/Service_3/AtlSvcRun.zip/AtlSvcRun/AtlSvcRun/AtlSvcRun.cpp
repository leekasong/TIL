// AtlSvcRun.cpp : Implementation of WinMain


#include "stdafx.h"
#include "resource.h"
#include "AtlSvcRun_i.h"


using namespace ATL;

#include <Sddl.h>
#include <AccCtrl.h>
#include <AclAPI.h>
#include <TlHelp32.h>
#include <WtsApi32.h>
#pragma comment(lib, "Wtsapi32.lib")

#define RM_SYSTEM_SESS0	0
#define RM_USER_SESS1	1
#define RM_SYSTEM_SESS1	2
#define RUN_MODE	RM_SYSTEM_SESS1

#include <stdio.h>

class CAtlSvcRunModule : public ATL::CAtlServiceModuleT< CAtlSvcRunModule, IDS_SERVICENAME >
{
	HANDLE m_hevExit;
public :
	DECLARE_LIBID(LIBID_AtlSvcRunLib)
	DECLARE_REGISTRY_APPID_RESOURCEID(IDR_ATLSVCRUN, "{F99D6412-3B9E-4D81-891B-6F12E6DE1907}")
		HRESULT InitializeSecurity() throw()
	{
		// TODO : Call CoInitializeSecurity and provide the appropriate security settings for your service
		// Suggested - PKT Level Authentication, 
		// Impersonation Level of RPC_C_IMP_LEVEL_IDENTIFY 
		// and an appropriate Non NULL Security Descriptor.

		return S_OK;
	}

		HRESULT PreMessageLoop(int nShowCmd);
		HRESULT PostMessageLoop() throw();
		void RunMessageLoop() throw();
		void OnStop();
	};

CAtlSvcRunModule _AtlModule;



//
extern "C" int WINAPI _tWinMain(HINSTANCE /*hInstance*/, HINSTANCE /*hPrevInstance*/, 
								LPTSTR /*lpCmdLine*/, int nShowCmd)
{
	return _AtlModule.WinMain(nShowCmd);
}

HRESULT CAtlSvcRunModule::PreMessageLoop(int nShowCmd)
{
	m_hevExit = CreateEvent(NULL, TRUE, FALSE, NULL);
	if (m_hevExit == NULL)
		return HRESULT_FROM_WIN32(GetLastError());

	if (::InterlockedCompareExchange(&m_status.dwCurrentState,
		SERVICE_RUNNING, SERVICE_START_PENDING) == SERVICE_START_PENDING)
	{
		LogEvent(_T("Service started/resumed"));
		::SetServiceStatus(m_hServiceStatus, &m_status);
	}
	return S_OK;
}



HRESULT CAtlSvcRunModule::PostMessageLoop()
{
	CloseHandle(m_hevExit);
	return __super::PostMessageLoop();
}
void CAtlSvcRunModule::OnStop()
{
	SetEvent(m_hevExit);

	__super::OnStop();
}

HANDLE AcquireTokenForLocalSystem(DWORD dwSessionId)
{
	HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	if (hSnap == INVALID_HANDLE_VALUE) {
		return NULL;
	}

	DWORD dwWindLogonId = 0;
	PROCESSENTRY32 pe;
	pe.dwSize = sizeof(PROCESSENTRY32);
	if (!Process32First(hSnap, &pe)) {
		CloseHandle(hSnap);
		return NULL;
	}

	do {
		if (_tcsicmp(pe.szExeFile, _T("winlogon.exe")) == 0) {
			DWORD dwWLSessId = 0;
			if (ProcessIdToSessionId(pe.th32ProcessID, &dwWLSessId)) {
				if (dwWLSessId == dwSessionId) {
					dwWindLogonId = pe.th32ProcessID;
					break;
				}
			}
		}
	} while (Process32Next(hSnap, &pe));

	CloseHandle(hSnap);
	if (dwWindLogonId == 0) return NULL;

	HANDLE hWLToken = NULL; //������ ��ū
	HANDLE hWLProc = NULL; //��ū�� ������ Ÿ�� ���μ��� �ڵ�
	HANDLE hNewToken = NULL; //�����Ǵ� ���μ����� �ǳ��� ��ū

	try {
		hWLProc = OpenProcess(MAXIMUM_ALLOWED, FALSE, dwWindLogonId);

		if (!hWLProc) throw GetLastError();

		BOOL bIsOK = OpenProcessToken(
			hWLProc,
			TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY | TOKEN_DUPLICATE |
			TOKEN_ASSIGN_PRIMARY | TOKEN_ADJUST_SESSIONID |
			TOKEN_READ | TOKEN_WRITE,
			&hWLToken
		);

		if (!bIsOK) throw GetLastError();

		bIsOK = DuplicateTokenEx(hWLToken, MAXIMUM_ALLOWED, NULL,
			SecurityIdentification, TokenPrimary, &hNewToken);

		if (!bIsOK) throw GetLastError();

		
	}
	catch (DWORD hr) {
		ATLTRACE(_T("Error occurred, code = %d"), hr);
	}

	if (hWLProc) CloseHandle(hWLProc);
	if (hWLToken) CloseHandle(hWLToken);

	return hNewToken;
}

void CAtlSvcRunModule::RunMessageLoop() {
	TCHAR szCmdLine[MAX_PATH] = _T("E:\\mfc\\TestCustomControl\\Debug\\TestCustomControl.exe");
	
	HANDLE hToken = NULL;
	PROCESS_INFORMATION pi = { 0 };

	try {
#if (RUN_MODE == RM_SYSTEM_SESS0)
		STARTUPINFO si = { 0 };
		si.cb = sizeof(si);

		BOOL bIsOK = CreateProcess(
			NULL, szCmdLine, NULL, NULL,
			FALSE, NORMAL_PRIORITY_CLASS, NULL, NULL,
			&si, &pi
		);
#elif(RUN_MODE == RM_USER_SESS1)
		DWORD dwSessionId = WTSGetActiveConsoleSessionId();
		if (!WTSQueryUserToken(dwSessionId, &hToken))
			throw GetLastError();

		STARTUPINFO si = { 0 };
		si.cb = sizeof(si);
		BOOL bIsOK = CreateProcessAsUser(
			hToken,
			NULL, szCmdLine, NULL, NULL,
			FALSE, NORMAL_PRIORITY_CLASS, NULL, NULL,
			&si, &pi
		);

#else
		DWORD dwSessionId = WTSGetActiveConsoleSessionId();
		hToken = AcquireTokenForLocalSystem(dwSessionId);
		if (hToken == NULL)
			throw GetLastError();

		STARTUPINFO si = { 0 };
		si.cb = sizeof(si);

		BOOL bIsOK = CreateProcessAsUser(
			hToken, NULL, szCmdLine, NULL,
			NULL, FALSE, NORMAL_PRIORITY_CLASS, NULL,
			NULL, &si, &pi
		);

#endif

		if (!bIsOK) throw GetLastError();
		CloseHandle(pi.hThread);
		WaitForInputIdle(pi.hProcess, INFINITE);
		CloseHandle(hToken);
		CloseHandle(pi.hProcess);
	}
	catch (DWORD hr) {
		ATLTRACE(_T("Error occurred, code = %d"), hr);
		if (hToken != NULL) CloseHandle(hToken);
	}

	WaitForSingleObject(m_hevExit, INFINITE);
}