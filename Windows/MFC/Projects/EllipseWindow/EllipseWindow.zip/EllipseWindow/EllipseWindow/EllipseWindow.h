
// EllipseWindow.h : main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols


// CEllipseWindowApp:
// See EllipseWindow.cpp for the implementation of this class
//

class CEllipseWindowApp : public CWinApp
{
public:
	CEllipseWindowApp();

// Overrides
public:
	virtual BOOL InitInstance();

// Implementation

	DECLARE_MESSAGE_MAP()
};

extern CEllipseWindowApp theApp;