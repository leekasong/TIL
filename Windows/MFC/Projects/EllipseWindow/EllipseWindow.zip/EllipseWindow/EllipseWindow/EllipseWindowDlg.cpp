
// EllipseWindowDlg.cpp : implementation file
//

#include "stdafx.h"
#include "EllipseWindow.h"
#include "EllipseWindowDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CEllipseWindowDlg dialog



CEllipseWindowDlg::CEllipseWindowDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_ELLIPSEWINDOW_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	mp_pos = new CPoint();
	mp_prev = new CPoint();
	
}

void CEllipseWindowDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CEllipseWindowDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDOK, &CEllipseWindowDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CEllipseWindowDlg::OnBnClickedCancel)
	ON_WM_DESTROY()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_TIMER()
END_MESSAGE_MAP()


// CEllipseWindowDlg message handlers

BOOL CEllipseWindowDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	GetWindowRect(m_rect);
	GetWindowRect(m_cl_rect);
	ScreenToClient(m_cl_rect);

	HRGN h_region;
	h_region = ::CreateEllipticRgn(0, 0, 150, 150);
	SetWindowRgn(h_region, TRUE);
	DeleteObject(h_region);

	
	SetTimer(1, 30, NULL);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CEllipseWindowDlg::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	if (IsIconic())
	{

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		dc.FillSolidRect(0, 0, m_cl_rect.Width(), m_cl_rect.Height(), RGB(count, 0, 0));
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CEllipseWindowDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CEllipseWindowDlg::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here
//	CDialogEx::OnOK();
}


void CEllipseWindowDlg::OnBnClickedCancel()
{
	// TODO: Add your control notification handler code here
	CDialogEx::OnCancel();
}


void CEllipseWindowDlg::OnDestroy()
{
	CDialogEx::OnDestroy();
	if (mp_pos != NULL) {
		delete mp_pos;
		mp_pos = NULL;
	}
	if (mp_prev != NULL) {
		delete mp_prev;
		mp_prev = NULL;
	}
	KillTimer(1);
}


void CEllipseWindowDlg::OnLButtonDown(UINT nFlags, CPoint point)
{
	GetWindowRect(m_rect);
	m_click_flag = 1;
	GetCursorPos(mp_prev);

	CDialogEx::OnLButtonDown(nFlags, point);
}


void CEllipseWindowDlg::OnLButtonUp(UINT nFlags, CPoint point)
{
	m_click_flag = 0;
	ReleaseCapture();
	CDialogEx::OnLButtonUp(nFlags, point);
}


void CEllipseWindowDlg::OnMouseMove(UINT nFlags, CPoint point)
{
	GetCursorPos(mp_pos);
	CPoint dif(mp_pos->x - mp_prev->x, mp_pos->y - mp_prev->y);
	SetCapture();
	if (m_click_flag == 1) {
		MoveWindow(m_rect.left + dif.x, m_rect.top + dif.y, m_rect.Width(), m_rect.Height());
		
	}

	CDialogEx::OnMouseMove(nFlags, point);
}


void CEllipseWindowDlg::OnTimer(UINT_PTR nIDEvent)
{
	if (1 == nIDEvent) {
		if (direction == 1) {
			count += 5;
			if (count > 245) direction = 0;
		}
		else {
			count -= 5;
			if (count < 5) direction = 1;
		}
		Invalidate(FALSE);
	}

	CDialogEx::OnTimer(nIDEvent);
}
