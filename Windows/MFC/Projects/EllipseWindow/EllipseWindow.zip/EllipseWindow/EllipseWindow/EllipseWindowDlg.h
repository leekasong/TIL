
// EllipseWindowDlg.h : header file
//

#pragma once


// CEllipseWindowDlg dialog
class CEllipseWindowDlg : public CDialogEx
{
// Construction
public:
	CEllipseWindowDlg(CWnd* pParent = NULL);	// standard constructor
private:
	CPoint *mp_pos, *mp_prev;
	CRect m_rect, m_cl_rect;
	int m_click_flag = 0;
	int count = 0, direction = 0;
	
// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ELLIPSEWINDOW_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	afx_msg void OnDestroy();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};
