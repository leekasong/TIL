
// ExamComboExDlg.h : header file
//

#pragma once
#include "afxcmn.h"


// CExamComboExDlg dialog
class CExamComboExDlg : public CDialogEx
{
// Construction
public:
	CExamComboExDlg(CWnd* pParent = NULL);	// standard constructor
	CImageList m_imglist;
// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_EXAMCOMBOEX_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CComboBoxEx m_combo;
};
