
// ExamSharedMemoryDlg.h : header file
//

#pragma once
#include "afxwin.h"


// CExamSharedMemoryDlg dialog
class CExamSharedMemoryDlg : public CDialogEx
{
public:
	HANDLE m_hSend, m_hRecv[2], m_hExit;
	CWinThread* m_pThread;
	HANDLE m_hMap;
	char *mp_sm;
	
public:
	static UINT IPCProc(LPVOID pParam);
	
	BOOL InitSharedMemory();
// Construction
public:
	CExamSharedMemoryDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_EXAMSHAREDMEMORY_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CString m_edit_text;
	CListBox m_list;
	afx_msg void OnBnClickedButtonSend();
	afx_msg void OnDestroy();
	afx_msg void OnBnClickedCancel();
};
