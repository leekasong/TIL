
// ExamShmMemory2Dlg.h : header file
//

#pragma once
#include "afxwin.h"


// CExamShmMemory2Dlg dialog
class CExamShmMemory2Dlg : public CDialogEx
{
// Construction
public:
	HANDLE m_hSend, m_hRecv[2], m_hExit;
	CWinThread* m_pThread;
	HANDLE m_hMap;
	char *mp_sm;
	BOOL InitSharedMemory();
	CExamShmMemory2Dlg(CWnd* pParent = NULL);	// standard constructor
	static UINT CExamShmMemory2Dlg::IPCProc1(LPVOID pParam);
// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_EXAMSHMMEMORY2_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CListBox m_list;
	CString m_edit_text;
	afx_msg void OnBnClickedButtonSend();
	afx_msg void OnDestroy();
	afx_msg void OnBnClickedCancel();
};
