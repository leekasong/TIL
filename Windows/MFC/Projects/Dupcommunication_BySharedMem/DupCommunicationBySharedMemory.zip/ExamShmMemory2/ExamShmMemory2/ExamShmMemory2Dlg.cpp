
// ExamShmMemory2Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "ExamShmMemory2.h"
#include "ExamShmMemory2Dlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CExamShmMemory2Dlg dialog



CExamShmMemory2Dlg::CExamShmMemory2Dlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_EXAMSHMMEMORY2_DIALOG, pParent)
	, m_edit_text(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CExamShmMemory2Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_RECV, m_list);
	DDX_Text(pDX, IDC_EDIT_TEXT, m_edit_text);
}

BEGIN_MESSAGE_MAP(CExamShmMemory2Dlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_SEND, &CExamShmMemory2Dlg::OnBnClickedButtonSend)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDCANCEL, &CExamShmMemory2Dlg::OnBnClickedCancel)
END_MESSAGE_MAP()


// CExamShmMemory2Dlg message handlers

BOOL CExamShmMemory2Dlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	

	m_hSend = CreateEvent(NULL, FALSE, FALSE, NULL);
	m_hRecv[0] = CreateEvent(NULL, FALSE, FALSE, _T("SHM_RECV_0"));
	m_hRecv[1] = CreateEvent(NULL, FALSE, FALSE, _T("SHM_RECV_1"));
	m_hExit = CreateEvent(NULL, TRUE, FALSE, _T("SHM_EXIT"));
	InitSharedMemory();


	m_pThread = AfxBeginThread(IPCProc1, this);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CExamShmMemory2Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CExamShmMemory2Dlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CExamShmMemory2Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}
BOOL CExamShmMemory2Dlg::InitSharedMemory()
{
	m_hMap = ::CreateFileMapping(INVALID_HANDLE_VALUE, NULL,
		PAGE_READWRITE, 0, sizeof(char) * 128,
		_T("IPC_TEST_SHARED_MEMORY"));
	if (::GetLastError() == ERROR_ALREADY_EXISTS) {
		m_hMap = ::OpenFileMapping(FILE_MAP_ALL_ACCESS, FALSE, _T("IPC_TEST_SHARED_MEMORY"));
	}

	if (m_hMap == NULL) {
		AfxMessageBox(_T("Error : failed to create file mapping"));
		return FALSE;
	}

	mp_sm = (char *)::MapViewOfFile(m_hMap, FILE_MAP_ALL_ACCESS,
		0, 0, sizeof(char) * 128);
	if (!mp_sm) {
		AfxMessageBox(_T("Error : failed to create file mapping"));
		return FALSE;
	}

	return TRUE;
}


void CExamShmMemory2Dlg::OnBnClickedButtonSend()
{
	UpdateData();
	CString tmp = _T("[Host] : ");
	tmp += m_edit_text;
	m_edit_text = tmp;
	SetEvent(m_hSend);
	
}
inline BOOL KS_WideToMulti(PCHAR pMultiStr, PWCHAR pWideStr) {

	if (pMultiStr == NULL || pWideStr == NULL) {
		return FALSE;
	}
	int len = ::WideCharToMultiByte(CP_ACP, 0, pWideStr, -1, NULL, 0, NULL, NULL);
	::WideCharToMultiByte(CP_ACP, 0, pWideStr, -1, pMultiStr, len, NULL, NULL);
	return TRUE;
}

//char * -> wchar_t *
inline BOOL KS_MultiToWide(PWCHAR pWideStr, PCHAR pMultiStr) {
	if (pMultiStr == NULL || pWideStr == NULL) {
		return FALSE;
	}
	int len = ::MultiByteToWideChar(CP_ACP, 0, pMultiStr, -1, NULL, 0);
	::MultiByteToWideChar(CP_ACP, 0, pMultiStr, -1, pWideStr, len);
	return TRUE;
}

UINT CExamShmMemory2Dlg::IPCProc1(LPVOID pParam) {
	CExamShmMemory2Dlg *pDlg = (CExamShmMemory2Dlg *)pParam;

	HANDLE arrEvent[3] = { pDlg->m_hExit, pDlg->m_hSend, pDlg->m_hRecv[1] };
	BOOL bExit = FALSE;
	while (bExit == FALSE) {
		DWORD dwWaitCode = WaitForMultipleObjects(3, arrEvent, FALSE, INFINITE);
		if (dwWaitCode == WAIT_FAILED) {
			CString err;
			err.Format(_T("WaitForMultipleObjects error : %d"), GetLastError());
			AfxMessageBox(err);
			break;
		}

		switch (dwWaitCode)
		{
		case WAIT_OBJECT_0:
			bExit = TRUE;
			break;
		case WAIT_OBJECT_0 + 1:
		{
			//send
			char *p_temp = new char[(pDlg->m_edit_text.GetLength() + 1) * 2]{ 0 };
			KS_WideToMulti(p_temp, pDlg->m_edit_text.GetBuffer());
			char *pTempSm = pDlg->mp_sm;
			*((int *)(pTempSm)) = strlen(p_temp) + 1;
			CopyMemory(pDlg->mp_sm + 4, p_temp, strlen(p_temp) + 1);
			pDlg->m_list.InsertString(-1, pDlg->m_edit_text);
			delete[] p_temp;
			::SetEvent(pDlg->m_hRecv[0]);
			break;
		}
		case WAIT_OBJECT_0 + 2:
		{
			
			//recv
			char buf[255] = { 0 };
			int size = 0;
			size = *((int *)(pDlg->mp_sm));
			CopyMemory(buf, pDlg->mp_sm + 4, size);

			wchar_t p_temp[255] = { 0 };
			KS_MultiToWide(p_temp, buf);
			pDlg->m_list.InsertString(-1, p_temp);
			break;
		}
		}

	}

	return 0;
}

void CExamShmMemory2Dlg::OnDestroy()
{
	CDialogEx::OnDestroy();
	
	WaitForSingleObject(m_pThread->m_hThread, INFINITE);
	CloseHandle(m_hExit);
	CloseHandle(m_hRecv[0]); 
	CloseHandle(m_hRecv[1]);
	CloseHandle(m_hSend);
}


void CExamShmMemory2Dlg::OnBnClickedCancel()
{
	SetEvent(m_hExit);
	CDialogEx::OnCancel();
}
