
// ExamListComboDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ExamListCombo.h"
#include "ExamListComboDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CExamListComboDlg dialog



CExamListComboDlg::CExamListComboDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_EXAMLISTCOMBO_DIALOG, pParent)
	, m_strInput(_T(""))
	, m_strAddress(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CExamListComboDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_list);
	DDX_Text(pDX, IDC_INPUT_EDIT, m_strInput);
	DDX_Control(pDX, IDC_COMBO1, m_combo);
	DDX_CBString(pDX, IDC_COMBO1, m_strAddress);
}

BEGIN_MESSAGE_MAP(CExamListComboDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_INSERT_BTN, &CExamListComboDlg::OnBnClickedInsertBtn)
	ON_BN_CLICKED(IDC_ADD_BTN, &CExamListComboDlg::OnBnClickedAddBtn)
	ON_BN_CLICKED(IDC_ADRRESS_BTN, &CExamListComboDlg::OnBnClickedAdrressBtn)
	ON_CBN_SELCHANGE(IDC_COMBO1, &CExamListComboDlg::OnCbnSelchangeCombo1)
END_MESSAGE_MAP()


// CExamListComboDlg message handlers

BOOL CExamListComboDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CExamListComboDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CExamListComboDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CExamListComboDlg::OnBnClickedInsertBtn()
{
	UpdateData();
	m_list.InsertString(0, m_strInput);
}


void CExamListComboDlg::OnBnClickedAddBtn()
{
	UpdateData();
	m_list.AddString(m_strInput);
}


void CExamListComboDlg::OnBnClickedAdrressBtn()
{
	m_strAddress = _T("Helo");
	m_combo.AddString(m_strAddress);
	m_list.AddString(m_strAddress);

	m_combo.SetEditSel(0, -1);
	m_combo.Clear();
}


void CExamListComboDlg::OnCbnSelchangeCombo1()
{
	// TODO: Add your control notification handler code here
}
