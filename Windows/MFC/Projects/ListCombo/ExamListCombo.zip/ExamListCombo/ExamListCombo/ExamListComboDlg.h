
// ExamListComboDlg.h : header file
//

#pragma once
#include "afxwin.h"


// CExamListComboDlg dialog
class CExamListComboDlg : public CDialogEx
{
// Construction
public:
	CExamListComboDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_EXAMLISTCOMBO_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CListBox m_list;
	CString m_strInput;
	afx_msg void OnBnClickedInsertBtn();
	afx_msg void OnBnClickedAddBtn();
	CComboBox m_combo;
	CString m_strAddress;
	afx_msg void OnBnClickedAdrressBtn();
	afx_msg void OnCbnSelchangeCombo1();
};
