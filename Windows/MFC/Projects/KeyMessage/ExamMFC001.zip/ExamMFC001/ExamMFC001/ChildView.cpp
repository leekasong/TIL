
// ChildView.cpp : implementation of the CChildView class
//

#include "stdafx.h"
#include "ExamMFC001.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildView

CChildView::CChildView()
{
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
	ON_WM_CREATE()
	ON_WM_KEYDOWN()
	ON_WM_CHAR()
	ON_WM_SYSKEYDOWN()
	ON_WM_SYSCHAR()
END_MESSAGE_MAP()



// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	
	// Do not call CWnd::OnPaint() for painting messages
}



int CChildView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	m_wndChild.Create(_T("STATIC"), _T("EXAM"), WS_CHILD | WS_VISIBLE | WS_BORDER, CRect(100, 100, 200, 200), this, 25000);

	return 0;
}


void CChildView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	TRACE(_T("OnKeyDown()\n"));
	CRect rect;
	int move = 10;
	CWnd *p_parent = GetParentFrame();
	p_parent->GetWindowRect(&rect);
	int nx = 0, ny = 0;

	switch (nChar) {
		case VK_LEFT:
			nx -= 10;
			break;
		case VK_RIGHT:
			nx += 10;
			break;
		case VK_UP:
			ny -= 10;
			break;
		case VK_DOWN:
			ny += 10;
			break;	
		
	}
	
	p_parent->SetWindowPos(NULL, rect.left + nx, rect.top + ny, 100, 100, SWP_NOSIZE);
	CWnd::OnKeyDown(nChar, nRepCnt, nFlags);
}


void CChildView::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	TRACE(_T("OnChar()\n"));
	CString str;
	str.Format(_T("%c"), nChar);

	if (nChar != VK_RETURN && nChar != VK_BACK && nChar != VK_ESCAPE) {
		m_wndChild.SetWindowTextW(str);
	}

	if (nChar == VK_ESCAPE) {
		
	}
	CWnd::OnChar(nChar, nRepCnt, nFlags);
}


void CChildView::OnSysKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	CString str;
	WORD keyState = ::GetKeyState(VK_SPACE);
	BYTE byHigh = HIBYTE(keyState);

	if (byHigh & 0x01) {
		str += _T("Alt + Space, ");
		keyState = ::GetKeyState(VK_CAPITAL);
		BYTE byLow = LOBYTE(keyState);
		if (byLow & 0x01) {
			str += _T("CAPS ON");
		}
		else {
			str += _T("CAPS OFF");
		}

		AfxMessageBox(str);
	}
	
	CWnd::OnSysKeyDown(nChar, nRepCnt, nFlags);
}


void CChildView::OnSysChar(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	if (nChar == VK_RETURN) {
		AfxMessageBox(_T("Alt + Enter"));
	}
	else if (nChar == 's' || nChar == 'S') {
		AfxMessageBox(_T("Alt + s"));
	}
	else if (nChar == 'x' || nChar == 'X') {
		CWnd *p_parent = GetParentFrame();
		p_parent->DestroyWindow();
	}
	
	CWnd::OnSysChar(nChar, nRepCnt, nFlags);
}
